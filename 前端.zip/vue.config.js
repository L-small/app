module.exports = {
  baseUrl: './',
}